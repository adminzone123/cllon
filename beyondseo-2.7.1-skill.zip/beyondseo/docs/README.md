# BeyondSEO documentation

Start with the task you want to complete. Each guide connects the commands, evidence and decisions needed for that job.

## Start using BeyondSEO

| I want to… | Read this |
|---|---|
| Install the engine and run my first crawl | [Setup and troubleshooting](setup.md) |
| Use Claude, Claude Code, Codex, ChatGPT Work, Hermes or OpenClaw | [Assistant installation](agent-installation.md) |
| Review package permissions or diagnose an installation rejection | [Package permissions](permissions.md) |
| Understand what the complete SEO house can do | [Capabilities and example questions](questions.md) |
| Practice without touching a live website | [Local examples](../examples/README.md) |
| Run the entire audit workflow | [SEO house workflow](../playbooks/core/seo-house-workflow.md) |
| Export a professional branded PDF or HTML report | [Report design and content format](branded-reports.md) |

## Crawl and investigate

| Guide | Covers |
|---|---|
| [CLI reference](../references/crawler.md) | Commands, arguments, scope, limits and evidence outputs |
| [Browser behavior](browser.md) | HTTP versus JavaScript, waiting, scrolling, public dependencies and access failures |
| [Discovery and competitor research](discovery-and-competitors.md) | Native and host fallbacks, reviewed business profiles, relevant competitors and evidence-based findings |
| [Browser-assisted search](browser-search.md) | Reuse a host browser, Google navigation and optional free Chromium setup |
| [Discovery diagnostics](discovery-diagnostics.md) | Distinguish installation, execution, network, provider and parsing failures |
| [Architecture](architecture.md) | Fetching, extraction, queue persistence, modules and Python usage |
| [Capability map](../references/capabilities.md) | What is implemented, what is guided analysis and what requires additional evidence |

## Reputation and backlinks

| Guide | Covers |
|---|---|
| [Source catalog](backlink-source-catalog.md) | 206 website/community entries from the source PDF, with source claims and review status |
| [Posting guide](backlink-posting-guide.md) | Website-specific 15/20-source plans: what to write, how to post, timing and authority limits |
| [Prospect directory](reputation-prospects.md) | Seven additional researched routes for credible profiles and recognition |
| [Scoring explained](scoring-explained.md) | What the score means, why confidence matters and a worked example |
| [Complete reputation method](../references/reputation.md) | Discovery/import, native verification, source reviews, formulas and limitations |
| [Reputation growth plan](../playbooks/backlink-system/reputation-growth-plan.md) | Relevant contributions, useful assets, review evidence and next actions |

## Strategy, content and follow-up

| Guide | Covers |
|---|---|
| [The complete SEO house](seo-house.md) | SEO, AEO, GEO, entities, authority, reputation and how they connect |
| [Audit delivery standard](../references/audit-delivery.md) | Friendly reports, required audit areas, competitors and actionable plans |
| [Friendly advisor](../playbooks/core/friendly-advisor.md) | How to explain findings and write useful client advice |
| [Complete plan template](../playbooks/templates/complete-seo-plan.md) | Priorities, responsibilities, dependencies and acceptance checks |
| [Review and improve](operations.md) | Comparisons, bounded loops, hosting access, reviewed edits and rollback |
| [Measurement boundaries](../references/measurement-boundaries.md) | What a crawl establishes and which claims need separate measurements |

## Project and community

[Development](development.md) · [Contributing](../CONTRIBUTING.md) · [Security](../SECURITY.md) · [Changelog](../CHANGELOG.md) · [MIT license](../LICENSE) · [Dependency notices](../THIRD_PARTY_NOTICES.md)

Questions about expected behavior belong in a [GitHub issue](https://github.com/beyondtahir/beyondseo/issues). Include the version, command, environment and a small redacted reproduction. Contact [Beyond Tahir](https://beyondtahir.com) for consulting, training or private business context.

- [Deep research and fair competitor comparisons](deep-research.md): browser-first discovery, shared budgets, keyword/AI-readiness analysis and evidence-supported standing.
