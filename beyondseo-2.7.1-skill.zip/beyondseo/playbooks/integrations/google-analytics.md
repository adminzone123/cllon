# Google Analytics Workflow

How BeyondSEO should use GA4 data.

---

## Key Data

Organic landing pages, sessions, engagement, conversions, events, source/medium, paths, and revenue where relevant.

## Use Cases

Find pages with traffic but low conversion, conversion tracking gaps, and landing page quality issues.

## Output

Tie SEO traffic to business outcomes, not vanity sessions.
